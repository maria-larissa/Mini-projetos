#include <stdio.h>
#include <string.h>

int gerarRelatorio();

int main(){
    printf("\nForam adicionados %d novos registros no arquivo.\n",gerarRelatorio());
    return 0;
}

/*Função que gera o relatório*/
int gerarRelatorio(){
    int quant_registros=0;
    FILE *resultado = fopen("resultado.dat","w");
    FILE *industrias = fopen("industrias.dat","r");
    if (industrias == NULL){
        printf("\nErro na leitura do arquivo industrias!\n");
    }else{
            int codigo_industria, codigo_produto, maior_risco;
            char nome_industria[30], nome_produto[30], material_produto[30];
            char indus_printar[30], prod_printar[30], material_printar[30];
            while(fscanf(industrias,"%d %s", &codigo_industria, &nome_industria) == 2){
                int cont = 0,risco_produto = 0;
                FILE *produtos = fopen("produtos.dat","r");
                if(produtos == NULL){
                printf("\nErro na leitura do arquivo produtos!\n");
                }else {
                    while(fscanf(produtos,"%s %d %s %d", &nome_produto,&codigo_produto, &material_produto,&risco_produto) != EOF){
                        if(codigo_produto == codigo_industria){
                            if(cont  == 0){
                                maior_risco= risco_produto;
                                strcpy(indus_printar, nome_industria);
                                strcpy(prod_printar, nome_produto);
                                strcpy(material_printar, material_produto);
                                ++cont;
                            }
                            if( risco_produto>maior_risco){
                                maior_risco = risco_produto;
                                strcpy(indus_printar, nome_industria);
                                strcpy(prod_printar, nome_produto);
                                strcpy(material_printar, material_produto);
                                ++cont;    
                            }
                        }
                    }
                    fprintf(resultado,"%s %s %s\n", indus_printar, prod_printar, material_printar);
                    ++quant_registros;
                }
                fclose(produtos);
            }

        }
    fclose(resultado);
    fclose(industrias);
    return quant_registros;
}